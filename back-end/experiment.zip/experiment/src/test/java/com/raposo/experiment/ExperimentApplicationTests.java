package com.raposo.experiment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExperimentApplicationTests {

	@Test
	void contextLoads() {
	}

}
